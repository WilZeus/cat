player_manager.AddValidModel( "CATPANTS", 		"models/player/catpants.mdl" );
list.Set( "PlayerOptionsModel", "CATPANTS", 	"models/player/catpants.mdl" );
